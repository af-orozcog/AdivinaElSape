package uniandes.cupi2.adivinaQuien.servidor.mundo;

public class AdivinaQuienServidorException extends Exception
{
	//--------------------------------
	// Constructor
	//-------------------------------
	
	/**
	 * Construye una nueva excepcion
	 * @param pMensaje
	 */
	public AdivinaQuienServidorException ( String pMensaje)
	{
		super(pMensaje);
	}

}
